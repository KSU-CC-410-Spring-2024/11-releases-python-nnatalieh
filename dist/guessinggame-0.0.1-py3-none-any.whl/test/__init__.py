"""Test Package for guessing game.

Author: Natalie Harris nharri29@ksu.edu
Version: 0.1
"""
